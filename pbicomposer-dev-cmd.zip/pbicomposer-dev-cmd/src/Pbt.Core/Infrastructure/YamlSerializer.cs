using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace Pbt.Core.Infrastructure;

/// <summary>
/// Service for serializing and deserializing YAML files with snake_case convention
/// </summary>
public class YamlSerializer
{
    private readonly IDeserializer _deserializer;
    private readonly ISerializer _serializer;

    public YamlSerializer()
    {
        // Configure deserializer (YAML -> C#)
        // snake_case in YAML maps to PascalCase in C#
        _deserializer = new DeserializerBuilder()
            .WithNamingConvention(UnderscoredNamingConvention.Instance)
            .IgnoreUnmatchedProperties()
            .Build();

        // Configure serializer (C# -> YAML)
        // PascalCase in C# maps to snake_case in YAML
        _serializer = new SerializerBuilder()
            .WithNamingConvention(UnderscoredNamingConvention.Instance)
            .ConfigureDefaultValuesHandling(DefaultValuesHandling.OmitNull)
            .Build();
    }

    /// <summary>
    /// Load and deserialize a YAML file
    /// </summary>
    public T LoadFromFile<T>(string filePath)
    {
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException($"YAML file not found: {filePath}");
        }

        try
        {
            var yaml = File.ReadAllText(filePath);
            return _deserializer.Deserialize<T>(yaml);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to parse YAML file: {filePath}", ex);
        }
    }

    /// <summary>
    /// Deserialize YAML string to object
    /// </summary>
    public T Deserialize<T>(string yaml)
    {
        try
        {
            return _deserializer.Deserialize<T>(yaml);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to deserialize YAML", ex);
        }
    }

    /// <summary>
    /// Save object to YAML file
    /// </summary>
    public void SaveToFile<T>(T obj, string filePath)
    {
        try
        {
            var yaml = _serializer.Serialize(obj);

            // Ensure directory exists
            var directory = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            File.WriteAllText(filePath, yaml);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to save YAML file: {filePath}", ex);
        }
    }

    /// <summary>
    /// Serialize object to YAML string
    /// </summary>
    public string Serialize<T>(T obj)
    {
        try
        {
            return _serializer.Serialize(obj);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Failed to serialize to YAML", ex);
        }
    }
}
