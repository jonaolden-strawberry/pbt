using Microsoft.AnalysisServices.Tabular;
using Pbt.Core.Models;

namespace Pbt.Core.Services;

/// <summary>
/// Composes TOM Database objects from model definitions
/// </summary>
public class ModelComposer
{
    private readonly TableRegistry _tableRegistry;
    private LineageManifestService? _lineageService;
    private ProjectDefinition? _project;
    private Dictionary<string, ConnectorConfig> _connectors = new();

    public ModelComposer(TableRegistry tableRegistry)
    {
        _tableRegistry = tableRegistry;
    }

    /// <summary>
    /// Register a connector configuration for shared expression generation
    /// </summary>
    public void RegisterConnector(ConnectorConfig connector)
    {
        if (!_connectors.ContainsKey(connector.Name))
        {
            _connectors[connector.Name] = connector;
        }
    }

    /// <summary>
    /// Compose a TOM Database from a model definition
    /// </summary>
    /// <param name="modelDef">Model definition</param>
    /// <param name="compatibilityLevel">Power BI compatibility level</param>
    /// <param name="lineageService">Optional lineage manifest service for tag management</param>
    /// <param name="project">Optional project definition for format strings</param>
    /// <returns>TOM Database object</returns>
    public Database ComposeModel(ModelDefinition modelDef, int compatibilityLevel = 1600, LineageManifestService? lineageService = null, ProjectDefinition? project = null)
    {
        _lineageService = lineageService;
        _project = project;

        var database = new Database
        {
            Name = modelDef.Name,
            CompatibilityLevel = compatibilityLevel,
            Model = new Model
            {
                Name = modelDef.Name
            }
        };

        var model = database.Model;

        // 1. Add tables
        foreach (var tableRef in modelDef.Tables)
        {
            var tableDef = _tableRegistry.GetTable(tableRef.Ref);
            var table = BuildTable(tableDef);
            model.Tables.Add(table);
        }

        // 2. Add relationships
        var relationshipCounter = new Dictionary<string, int>();
        foreach (var relDef in modelDef.Relationships)
        {
            ValidateRelationship(relDef, model);
            var relationship = BuildRelationship(relDef, model, relationshipCounter);
            model.Relationships.Add(relationship);
        }

        // 3. Add model-level measures (override table-level measures with same name)
        foreach (var measureDef in modelDef.Measures)
        {
            var table = model.Tables.Find(measureDef.Table);
            if (table == null)
            {
                throw new InvalidOperationException(
                    $"Measure '{measureDef.Name}' references table '{measureDef.Table}' which is not in the model");
            }

            // Remove existing table-level measure with same name (model-level wins)
            var existing = table.Measures.Find(measureDef.Name);
            if (existing != null)
            {
                table.Measures.Remove(existing);
            }

            var measure = BuildMeasure(measureDef, measureDef.Table);
            table.Measures.Add(measure);
        }

        // 4. Add shared connector expressions
        foreach (var connector in _connectors.Values)
        {
            var expression = BuildConnectorExpression(connector);
            model.Expressions.Add(expression);
        }

        return database;
    }

    /// <summary>
    /// Build a TOM Table from a table definition
    /// </summary>
    private Table BuildTable(TableDefinition tableDef)
    {
        var table = new Table
        {
            Name = tableDef.Name,
            Description = tableDef.Description,
            IsHidden = tableDef.IsHidden
        };

        // Add partition with M expression
        string? mExpression = null;

        // MExpression has priority (manual override wins)
        if (!string.IsNullOrWhiteSpace(tableDef.MExpression))
        {
            mExpression = tableDef.MExpression;
        }
        // Generate M expression from Source if MExpression is not provided
        else if (tableDef.Source != null)
        {
            mExpression = GenerateMExpressionFromSource(tableDef.Source, tableDef);
        }

        if (!string.IsNullOrWhiteSpace(mExpression))
        {
            var partition = new Partition
            {
                Name = tableDef.Name,
                Source = new MPartitionSource
                {
                    Expression = mExpression
                }
            };
            table.Partitions.Add(partition);
        }

        // Add columns
        foreach (var colDef in tableDef.Columns)
        {
            var column = BuildColumn(colDef, tableDef.Name);
            table.Columns.Add(column);
        }

        // Set SortByColumn references after all columns are added
        foreach (var colDef in tableDef.Columns)
        {
            if (!string.IsNullOrWhiteSpace(colDef.SortByColumn))
            {
                var column = table.Columns.Find(colDef.Name);
                var sortByColumn = table.Columns.Find(colDef.SortByColumn);
                if (column != null && sortByColumn != null)
                {
                    column.SortByColumn = sortByColumn;
                }
            }
        }

        // Add hierarchies
        foreach (var hierarchyDef in tableDef.Hierarchies)
        {
            var hierarchy = BuildHierarchy(hierarchyDef, table);
            table.Hierarchies.Add(hierarchy);
        }

        // Add table-level measures
        foreach (var measureDef in tableDef.Measures)
        {
            var measure = BuildMeasure(measureDef, tableDef.Name);
            table.Measures.Add(measure);
        }

        // Generate lineage tag (basic implementation, will be enhanced in Phase 4.5)
        if (string.IsNullOrWhiteSpace(tableDef.LineageTag))
        {
            table.LineageTag = GenerateLineageTag(tableDef.Name, tableDef.Name, "Table");
        }
        else
        {
            table.LineageTag = tableDef.LineageTag;
        }

        return table;
    }

    /// <summary>
    /// Build a TOM Column from a column definition
    /// Returns either a DataColumn or CalculatedColumn based on whether Expression is set
    /// </summary>
    private Column BuildColumn(ColumnDefinition colDef, string tableName)
    {
        // If Expression is set, create a calculated column
        if (!string.IsNullOrWhiteSpace(colDef.Expression))
        {
            return BuildCalculatedColumn(colDef, tableName);
        }

        // Otherwise create a data column
        return BuildDataColumn(colDef, tableName);
    }

    /// <summary>
    /// Build a TOM DataColumn from a column definition
    /// </summary>
    private DataColumn BuildDataColumn(ColumnDefinition colDef, string tableName)
    {
        var column = new DataColumn
        {
            Name = colDef.Name,
            DataType = ParseDataType(colDef.Type),
            SourceColumn = colDef.SourceColumn ?? colDef.Name,
            Description = colDef.Description,
            IsHidden = colDef.IsHidden ?? false
        };

        // Set display folder if specified
        if (!string.IsNullOrWhiteSpace(colDef.DisplayFolder))
        {
            column.DisplayFolder = colDef.DisplayFolder;
        }

        // Apply format string from column definition or project config
        var formatString = colDef.FormatString;
        if (string.IsNullOrWhiteSpace(formatString) && _project != null)
        {
            // Try to get format string from project config based on column type
            _project.FormatStrings.TryGetValue(colDef.Type, out formatString);
        }

        if (!string.IsNullOrWhiteSpace(formatString))
        {
            column.FormatString = formatString;
        }

        // Generate lineage tag
        if (string.IsNullOrWhiteSpace(colDef.LineageTag))
        {
            column.LineageTag = GenerateLineageTag(tableName, colDef.Name, "Column");
        }
        else
        {
            column.LineageTag = colDef.LineageTag;
        }

        return column;
    }

    /// <summary>
    /// Build a TOM CalculatedColumn from a column definition with an expression
    /// </summary>
    private CalculatedColumn BuildCalculatedColumn(ColumnDefinition colDef, string tableName)
    {
        var column = new CalculatedColumn
        {
            Name = colDef.Name,
            DataType = ParseDataType(colDef.Type),
            Expression = colDef.Expression!,
            Description = colDef.Description,
            IsHidden = colDef.IsHidden ?? false
        };

        // Set display folder if specified
        if (!string.IsNullOrWhiteSpace(colDef.DisplayFolder))
        {
            column.DisplayFolder = colDef.DisplayFolder;
        }

        // Apply format string from column definition or project config
        var formatString = colDef.FormatString;
        if (string.IsNullOrWhiteSpace(formatString) && _project != null)
        {
            // Try to get format string from project config based on column type
            _project.FormatStrings.TryGetValue(colDef.Type, out formatString);
        }

        if (!string.IsNullOrWhiteSpace(formatString))
        {
            column.FormatString = formatString;
        }

        // Generate lineage tag
        if (string.IsNullOrWhiteSpace(colDef.LineageTag))
        {
            column.LineageTag = GenerateLineageTag(tableName, colDef.Name, "Column");
        }
        else
        {
            column.LineageTag = colDef.LineageTag;
        }

        return column;
    }

    /// <summary>
    /// Build a TOM Hierarchy from a hierarchy definition
    /// </summary>
    private Hierarchy BuildHierarchy(HierarchyDefinition hierarchyDef, Table table)
    {
        var hierarchy = new Hierarchy
        {
            Name = hierarchyDef.Name,
            Description = hierarchyDef.Description
        };

        // Set display folder if specified
        if (!string.IsNullOrWhiteSpace(hierarchyDef.DisplayFolder))
        {
            hierarchy.DisplayFolder = hierarchyDef.DisplayFolder;
        }

        foreach (var levelDef in hierarchyDef.Levels)
        {
            var column = table.Columns.Find(levelDef.Column);
            if (column == null)
            {
                throw new InvalidOperationException(
                    $"Hierarchy '{hierarchyDef.Name}' level '{levelDef.Name}' references column '{levelDef.Column}' which does not exist in table '{table.Name}'");
            }

            var level = new Level
            {
                Name = levelDef.Name,
                Column = column,
                Ordinal = hierarchy.Levels.Count
            };
            hierarchy.Levels.Add(level);
        }

        // Generate lineage tag
        if (string.IsNullOrWhiteSpace(hierarchyDef.LineageTag))
        {
            hierarchy.LineageTag = GenerateLineageTag(table.Name, hierarchyDef.Name, "Hierarchy");
        }
        else
        {
            hierarchy.LineageTag = hierarchyDef.LineageTag;
        }

        return hierarchy;
    }

    /// <summary>
    /// Build a TOM Relationship from a relationship definition
    /// </summary>
    private SingleColumnRelationship BuildRelationship(RelationshipDefinition relDef, Model model, Dictionary<string, int> relationshipCounter)
    {
        var fromTable = model.Tables.Find(relDef.FromTable);
        var toTable = model.Tables.Find(relDef.ToTable);
        var fromColumn = fromTable!.Columns.Find(relDef.FromColumn);
        var toColumn = toTable!.Columns.Find(relDef.ToColumn);

        // Generate UUID for relationship name (deterministic if lineage service is available)
        var relationshipId = GenerateRelationshipId(relDef, relationshipCounter);

        var relationship = new SingleColumnRelationship
        {
            Name = relationshipId,
            FromColumn = fromColumn,
            ToColumn = toColumn,
            IsActive = relDef.Active
        };

        // Parse cardinality
        ParseCardinality(relDef.Cardinality, out var fromCardinality, out var toCardinality);
        relationship.FromCardinality = fromCardinality;
        relationship.ToCardinality = toCardinality;

        // Parse cross filter direction
        if (!string.IsNullOrWhiteSpace(relDef.CrossFilterDirection))
        {
            relationship.CrossFilteringBehavior = ParseCrossFilterDirection(relDef.CrossFilterDirection);
        }

        return relationship;
    }

    /// <summary>
    /// Generate a deterministic UUID for a relationship
    /// </summary>
    private string GenerateRelationshipId(RelationshipDefinition relDef, Dictionary<string, int> relationshipCounter)
    {
        // Create base key for the relationship
        var baseKey = $"{relDef.FromTable}.{relDef.FromColumn}->{relDef.ToTable}.{relDef.ToColumn}";

        // Track occurrences of this relationship pattern
        if (!relationshipCounter.TryGetValue(baseKey, out var count))
        {
            relationshipCounter[baseKey] = 0;
        }
        else
        {
            relationshipCounter[baseKey] = ++count;
        }

        // Include count in key for uniqueness
        var relationshipKey = count > 0 ? $"{baseKey}#{count}" : baseKey;

        if (_lineageService != null)
        {
            return _lineageService.GetOrGenerateRelationshipTag(relationshipKey);
        }

        // Fallback to random GUID if no lineage service
        return Guid.NewGuid().ToString();
    }

    /// <summary>
    /// Build a TOM Measure from a measure definition
    /// </summary>
    private Measure BuildMeasure(MeasureDefinition measureDef, string tableName)
    {
        var measure = new Measure
        {
            Name = measureDef.Name,
            Expression = measureDef.Expression,
            Description = measureDef.Description,
            IsHidden = measureDef.IsHidden ?? false
        };

        if (!string.IsNullOrWhiteSpace(measureDef.FormatString))
        {
            measure.FormatString = measureDef.FormatString;
        }

        if (!string.IsNullOrWhiteSpace(measureDef.DisplayFolder))
        {
            measure.DisplayFolder = measureDef.DisplayFolder;
        }

        // Generate lineage tag
        if (string.IsNullOrWhiteSpace(measureDef.LineageTag))
        {
            measure.LineageTag = GenerateLineageTag(tableName, measureDef.Name, "Measure");
        }
        else
        {
            measure.LineageTag = measureDef.LineageTag;
        }

        return measure;
    }

    /// <summary>
    /// Validate that a relationship is valid
    /// </summary>
    private void ValidateRelationship(RelationshipDefinition relDef, Model model)
    {
        // Ensure both tables are in the model
        var fromTable = model.Tables.Find(relDef.FromTable);
        if (fromTable == null)
        {
            throw new InvalidOperationException(
                $"Relationship from table '{relDef.FromTable}' not found in model");
        }

        var toTable = model.Tables.Find(relDef.ToTable);
        if (toTable == null)
        {
            throw new InvalidOperationException(
                $"Relationship to table '{relDef.ToTable}' not found in model");
        }

        // Ensure columns exist
        var fromColumn = fromTable.Columns.Find(relDef.FromColumn);
        if (fromColumn == null)
        {
            throw new InvalidOperationException(
                $"Column '{relDef.FromColumn}' not found in table '{relDef.FromTable}'");
        }

        var toColumn = toTable.Columns.Find(relDef.ToColumn);
        if (toColumn == null)
        {
            throw new InvalidOperationException(
                $"Column '{relDef.ToColumn}' not found in table '{relDef.ToTable}'");
        }
    }

    /// <summary>
    /// Parse data type string to TOM DataType
    /// </summary>
    private DataType ParseDataType(string type)
    {
        return type.ToLowerInvariant() switch
        {
            "string" => DataType.String,
            "int64" => DataType.Int64,
            "datetime" => DataType.DateTime,
            "decimal" => DataType.Decimal,
            "double" => DataType.Double,
            "boolean" => DataType.Boolean,
            _ => throw new ArgumentException($"Unknown data type: {type}")
        };
    }

    /// <summary>
    /// Parse cardinality string to TOM enums
    /// </summary>
    private void ParseCardinality(string cardinality, out RelationshipEndCardinality from, out RelationshipEndCardinality to)
    {
        switch (cardinality)
        {
            case "ManyToOne":
                from = RelationshipEndCardinality.Many;
                to = RelationshipEndCardinality.One;
                break;
            case "OneToMany":
                from = RelationshipEndCardinality.One;
                to = RelationshipEndCardinality.Many;
                break;
            case "OneToOne":
                from = RelationshipEndCardinality.One;
                to = RelationshipEndCardinality.One;
                break;
            case "ManyToMany":
                from = RelationshipEndCardinality.Many;
                to = RelationshipEndCardinality.Many;
                break;
            default:
                throw new ArgumentException($"Unknown cardinality: {cardinality}");
        }
    }

    /// <summary>
    /// Parse cross filter direction string to TOM enum
    /// </summary>
    private CrossFilteringBehavior ParseCrossFilterDirection(string direction)
    {
        return direction switch
        {
            "Single" => CrossFilteringBehavior.OneDirection,
            "Both" => CrossFilteringBehavior.BothDirections,
            "Automatic" => CrossFilteringBehavior.Automatic,
            _ => throw new ArgumentException($"Unknown cross filter direction: {direction}. Valid values: Single, Both, Automatic")
        };
    }

    /// <summary>
    /// Generate a lineage tag using the manifest service if available,
    /// otherwise generate a random GUID
    /// </summary>
    private string GenerateLineageTag(string tableName, string objectName, string objectType)
    {
        if (_lineageService != null)
        {
            return objectType switch
            {
                "Table" => _lineageService.GetOrGenerateTableTag(tableName),
                "Column" => _lineageService.GetOrGenerateColumnTag(tableName, objectName),
                "Measure" => _lineageService.GetOrGenerateMeasureTag(tableName, objectName),
                "Hierarchy" => _lineageService.GetOrGenerateHierarchyTag(tableName, objectName),
                _ => Guid.NewGuid().ToString()
            };
        }

        // Fallback to random GUID if no lineage service
        return Guid.NewGuid().ToString();
    }

    /// <summary>
    /// Generate M expression from source metadata
    /// </summary>
    private string GenerateMExpressionFromSource(SourceDefinition source, TableDefinition tableDef)
    {
        // If custom query is provided, use it
        if (!string.IsNullOrWhiteSpace(source.Query))
        {
            return GenerateCustomQueryExpression(source, tableDef);
        }

        // Generate connector-specific M expression
        return source.Type.ToLowerInvariant() switch
        {
            "snowflake" => GenerateSnowflakeExpression(source, tableDef),
            "sqlserver" => GenerateSqlServerExpression(source, tableDef),
            _ => throw new NotSupportedException(
                $"Source type '{source.Type}' is not supported. Supported types: snowflake, sqlserver. " +
                $"Alternatively, provide a custom M expression in the 'MExpression' property.")
        };
    }

    /// <summary>
    /// Generate M expression for custom SQL query
    /// </summary>
    private string GenerateCustomQueryExpression(SourceDefinition source, TableDefinition tableDef)
    {
        // This is a generic query template - actual connector depends on source type
        var baseExpression = source.Type.ToLowerInvariant() switch
        {
            "snowflake" => $@"let
    Source = Snowflake.Databases(""{source.Connection}""),
    Database = Source{{[Name=""{source.Database}""]}},
    Query = Value.NativeQuery(Database, ""{source.Query}"")",
            "sqlserver" => $@"let
    Source = Sql.Database(""{source.Connection}"", ""{source.Database}""),
    Query = Value.NativeQuery(Source, ""{source.Query}"")",
            _ => throw new NotSupportedException($"Custom queries not supported for source type: {source.Type}")
        };

        // Add type transformation if M types are specified
        var typeTransform = GenerateTypeTransformation(tableDef, "Query");
        if (!string.IsNullOrEmpty(typeTransform))
        {
            return baseExpression + ",\n" + typeTransform + "\nin\n    TypedTable";
        }

        return baseExpression + "\nin\n    Query";
    }

    /// <summary>
    /// Generate M expression for Snowflake source
    /// </summary>
    private string GenerateSnowflakeExpression(SourceDefinition source, TableDefinition tableDef)
    {
        if (string.IsNullOrWhiteSpace(source.Database))
        {
            throw new InvalidOperationException("Snowflake source requires 'Database' property");
        }

        if (string.IsNullOrWhiteSpace(source.Table))
        {
            throw new InvalidOperationException("Snowflake source requires 'Table' property");
        }

        var schemaName = !string.IsNullOrWhiteSpace(source.Schema) ? source.Schema : "PUBLIC";
        string baseExpression;

        // Use shared connector if specified
        if (!string.IsNullOrWhiteSpace(source.Connector))
        {
            baseExpression = $@"let
    Source = {source.Connector},
    Database = Source{{[Name=""{source.Database}""]}},
    Schema = Database{{[Name=""{schemaName}""]}},
    Table = Schema{{[Name=""{source.Table}""]}}";
        }
        else
        {
            if (string.IsNullOrWhiteSpace(source.Connection))
            {
                throw new InvalidOperationException("Snowflake source requires 'Connection' or 'Connector' property");
            }

            baseExpression = $@"let
    Source = Snowflake.Databases(""{source.Connection}""),
    Database = Source{{[Name=""{source.Database}""]}},
    Schema = Database{{[Name=""{schemaName}""]}},
    Table = Schema{{[Name=""{source.Table}""]}}";
        }

        // Add type transformation if M types are specified
        var typeTransform = GenerateTypeTransformation(tableDef, "Table");
        if (!string.IsNullOrEmpty(typeTransform))
        {
            return baseExpression + ",\n" + typeTransform + "\nin\n    TypedTable";
        }

        return baseExpression + "\nin\n    Table";
    }

    /// <summary>
    /// Generate M expression for SQL Server source
    /// </summary>
    private string GenerateSqlServerExpression(SourceDefinition source, TableDefinition tableDef)
    {
        if (string.IsNullOrWhiteSpace(source.Connection))
        {
            throw new InvalidOperationException("SQL Server source requires 'Connection' property");
        }

        if (string.IsNullOrWhiteSpace(source.Database))
        {
            throw new InvalidOperationException("SQL Server source requires 'Database' property");
        }

        if (string.IsNullOrWhiteSpace(source.Table))
        {
            throw new InvalidOperationException("SQL Server source requires 'Table' property");
        }

        var schemaName = !string.IsNullOrWhiteSpace(source.Schema) ? source.Schema : "dbo";

        var baseExpression = $@"let
    Source = Sql.Database(""{source.Connection}"", ""{source.Database}""),
    Table = Source{{[Schema=""{schemaName}"",Item=""{source.Table}""]}}";

        // Add type transformation if M types are specified
        var typeTransform = GenerateTypeTransformation(tableDef, "Table");
        if (!string.IsNullOrEmpty(typeTransform))
        {
            return baseExpression + ",\n" + typeTransform + "\nin\n    TypedTable";
        }

        return baseExpression + "\nin\n    Table";
    }

    /// <summary>
    /// Generate type transformation M code using Table.TransformColumnTypes
    /// </summary>
    private string GenerateTypeTransformation(TableDefinition tableDef, string sourceStepName)
    {
        // Check if any columns have M types specified
        var columnsWithMTypes = tableDef.Columns
            .Where(c => !string.IsNullOrEmpty(c.MType) && !string.IsNullOrEmpty(c.SourceColumn))
            .ToList();

        if (columnsWithMTypes.Count == 0)
        {
            return string.Empty;
        }

        // Generate type list for Table.TransformColumnTypes
        var typeList = string.Join(",\n        ", columnsWithMTypes.Select(c =>
            $"{{\"{c.SourceColumn}\", {c.MType}}}"
        ));

        return $@"    TypedTable = Table.TransformColumnTypes({sourceStepName}, {{
        {typeList}
    }})";
    }

    /// <summary>
    /// Build a shared connector expression for reuse across tables
    /// </summary>
    private NamedExpression BuildConnectorExpression(ConnectorConfig connector)
    {
        var mExpression = connector.Name.ToLower() switch
        {
            var name when name.Contains("snowflake") => GenerateSnowflakeConnectorExpression(connector),
            var name when name.Contains("sqlserver") || name.Contains("sql") => GenerateSqlServerConnectorExpression(connector),
            _ => GenerateSnowflakeConnectorExpression(connector) // Default to Snowflake
        };

        var lineageTag = _lineageService != null
            ? _lineageService.GetOrGenerateRelationshipTag($"Connector:{connector.Name}")
            : Guid.NewGuid().ToString();

        var expression = new NamedExpression
        {
            Name = connector.Name,
            Expression = mExpression,
            LineageTag = lineageTag
        };

        return expression;
    }

    /// <summary>
    /// Generate M expression for Snowflake shared connector
    /// </summary>
    private string GenerateSnowflakeConnectorExpression(ConnectorConfig connector)
    {
        var options = new List<string>();

        if (!string.IsNullOrEmpty(connector.Implementation))
        {
            options.Add($"[Implementation=\"{connector.Implementation}\"]");
        }

        var optionsStr = options.Count > 0 ? ", " + string.Join(", ", options) : string.Empty;

        if (!string.IsNullOrEmpty(connector.Warehouse))
        {
            return $@"Snowflake.Databases(""{connector.Connection}"", ""{connector.Warehouse}""{optionsStr})";
        }

        return $@"Snowflake.Databases(""{connector.Connection}""{optionsStr})";
    }

    /// <summary>
    /// Generate M expression for SQL Server shared connector
    /// </summary>
    private string GenerateSqlServerConnectorExpression(ConnectorConfig connector)
    {
        // For SQL Server, we'd need database name, which should be in Connection
        return $@"Sql.Database(""{connector.Connection}"")";
    }
}

