namespace Pbt.Core.Models;

/// <summary>
/// Represents a model composition (from models/*.yaml)
/// </summary>
public class ModelDefinition
{
    /// <summary>
    /// Model name
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Model description
    /// </summary>
    public string? Description { get; set; }

    /// <summary>
    /// Tables included in this model (references to table registry)
    /// </summary>
    public List<TableReference> Tables { get; set; } = new();

    /// <summary>
    /// Relationships between tables
    /// </summary>
    public List<RelationshipDefinition> Relationships { get; set; } = new();

    /// <summary>
    /// Measures defined in this model
    /// </summary>
    public List<MeasureDefinition> Measures { get; set; } = new();

    /// <summary>
    /// File path where this model definition was loaded from
    /// </summary>
    public string? SourceFilePath { get; set; }
}
