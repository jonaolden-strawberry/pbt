namespace Pbt.Core.Models;

/// <summary>
/// Represents a table definition (from tables/*.yaml)
/// </summary>
public class TableDefinition
{
    /// <summary>
    /// Table name
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Table description
    /// </summary>
    public string? Description { get; set; }

    /// <summary>
    /// M expression (Power Query) for loading data
    /// </summary>
    public string? MExpression { get; set; }

    /// <summary>
    /// Lineage tag (optional override, usually auto-generated)
    /// </summary>
    public string? LineageTag { get; set; }

    /// <summary>
    /// Optional source metadata (alternative to MExpression)
    /// Used by PbiScaffold, can be converted to MExpression by PbiComposer at build time
    /// </summary>
    public SourceDefinition? Source { get; set; }

    /// <summary>
    /// Whether the table should be hidden from client tools
    /// </summary>
    public bool IsHidden { get; set; }

    /// <summary>
    /// Table columns
    /// </summary>
    public List<ColumnDefinition> Columns { get; set; } = new();

    /// <summary>
    /// Table hierarchies
    /// </summary>
    public List<HierarchyDefinition> Hierarchies { get; set; } = new();

    /// <summary>
    /// Table measures (DAX calculations)
    /// </summary>
    public List<MeasureDefinition> Measures { get; set; } = new();

    /// <summary>
    /// File path where this table definition was loaded from
    /// </summary>
    public string? SourceFilePath { get; set; }
}
