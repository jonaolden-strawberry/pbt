using System.CommandLine;
using Microsoft.AnalysisServices.Tabular;
using Pbt.Core.Infrastructure;
using Pbt.Core.Models;
using Pbt.Core.Services;

namespace Pbt.Commands;

public static class BuildCommand
{
    public static Command Create()
    {
        var projectPathArgument = new Argument<string>(
            "project-path",
            () => ".",
            "Path to the project directory (defaults to current directory)");

        var modelOption = new Option<string?>(
            "--model",
            "Build specific model only (optional)");

        var outputOption = new Option<string?>(
            "--output",
            "Override output directory");

        var noLineageTagsOption = new Option<bool>(
            "--no-lineage-tags",
            "Skip lineage tag generation");

        var command = new Command("build", "Build Power BI project (.pbip) from YAML definitions (use 'build model' for TMDL-only output)")
        {
            projectPathArgument,
            modelOption,
            outputOption,
            noLineageTagsOption
        };

        // Default handler: `pbt build [path]` produces PBIP output
        command.SetHandler((projectPath, modelName, outputPath, noLineageTags) =>
        {
            try
            {
                ExecuteProjectBuild(projectPath, modelName, outputPath, noLineageTags);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n✗ Build failed: {ex.Message}");
                Console.ResetColor();
                Environment.Exit(1);
            }
        }, projectPathArgument, modelOption, outputOption, noLineageTagsOption);

        // Add subcommands
        command.AddCommand(CreateModelSubcommand());

        return command;
    }

    #region Model Subcommand (TMDL Only)

    private static Command CreateModelSubcommand()
    {
        var projectPathArgument = new Argument<string>(
            "project-path",
            () => ".",
            "Path to the project directory (defaults to current directory)");

        var modelOption = new Option<string?>(
            "--model",
            "Build specific model only (optional)");

        var outputOption = new Option<string?>(
            "--output",
            "Override output directory");

        var noLineageTagsOption = new Option<bool>(
            "--no-lineage-tags",
            "Skip lineage tag generation");

        var command = new Command("model", "Build TMDL semantic model from YAML definitions")
        {
            projectPathArgument,
            modelOption,
            outputOption,
            noLineageTagsOption
        };

        command.SetHandler((projectPath, modelName, outputPath, noLineageTags) =>
        {
            try
            {
                ExecuteModelBuild(projectPath, modelName, outputPath, noLineageTags);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n✗ Build failed: {ex.Message}");
                Console.ResetColor();
                Environment.Exit(1);
            }
        }, projectPathArgument, modelOption, outputOption, noLineageTagsOption);

        return command;
    }

    private static void ExecuteModelBuild(string projectPath, string? modelName, string? outputPath, bool noLineageTags)
    {
        var models = ExecuteCoreBuild(projectPath, modelName, noLineageTags, out var project, out var lineageService);

        var targetPath = outputPath ?? Path.Combine(projectPath, "target");

        foreach (var (database, _, _) in models)
        {
            GenerateTmdlOutput(database, project.Name, targetPath, lineageService);
        }

        SaveLineageManifest(lineageService, projectPath);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\n✓ Build completed successfully");
        Console.ResetColor();
    }

    #endregion

    private static void ExecuteProjectBuild(string projectPath, string? modelName, string? outputPath, bool noLineageTags)
    {
        var models = ExecuteCoreBuild(projectPath, modelName, noLineageTags, out var project, out var lineageService);

        var targetPath = outputPath ?? Path.Combine(projectPath, "target");

        foreach (var (database, _, _) in models)
        {
            GeneratePbipOutput(database, project.Name, targetPath, lineageService);
        }

        SaveLineageManifest(lineageService, projectPath);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\n✓ Build completed successfully");
        Console.ResetColor();
    }

    #region Shared Build Logic

    private static List<(Database database, string modelFileName, string modelName)> ExecuteCoreBuild(
        string projectPath,
        string? modelName,
        bool noLineageTags,
        out ProjectDefinition project,
        out LineageManifestService? lineageService)
    {
        Console.WriteLine($"Building project: {projectPath}");
        Console.WriteLine();

        // Validate project path
        if (!Directory.Exists(projectPath))
        {
            throw new DirectoryNotFoundException($"Project directory not found: {projectPath}");
        }

        var serializer = new YamlSerializer();
        var assetLoader = new AssetLoader(serializer);

        // 1. Load project and resolve asset paths
        var (loadedProject, assetPaths) = assetLoader.LoadProject(projectPath);
        project = loadedProject;

        Console.WriteLine($"Project: {project.Name}");
        if (!string.IsNullOrWhiteSpace(project.Description))
        {
            Console.WriteLine($"Description: {project.Description}");
        }
        Console.WriteLine($"Compatibility Level: {project.CompatibilityLevel}");
        Console.WriteLine();

        // Display resolved asset paths
        Console.WriteLine("Asset paths (by priority):");
        Console.WriteLine($"  Tables: {assetPaths.TablePaths.Count} path(s)");
        foreach (var path in assetPaths.TablePaths)
        {
            Console.WriteLine($"    - {path}");
        }
        Console.WriteLine($"  Models: {assetPaths.ModelPaths.Count} path(s)");
        foreach (var path in assetPaths.ModelPaths)
        {
            Console.WriteLine($"    - {path}");
        }
        Console.WriteLine();

        // 2. Validate project
        var validator = new Validator(serializer);
        var validationResult = validator.ValidateProjectWithAssets(projectPath, assetPaths);

        if (!validationResult.IsValid)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(validationResult.FormatMessages());
            Console.ResetColor();
            throw new InvalidOperationException("Project validation failed");
        }

        if (validationResult.HasWarnings)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(validationResult.FormatMessages());
            Console.ResetColor();
            Console.WriteLine();
        }

        // 3. Load table registry from configured paths
        var registry = assetLoader.CreateTableRegistry(assetPaths);
        Console.WriteLine($"Loaded {registry.ListTables().Count} table definitions");
        Console.WriteLine();

        // 4. Find model definitions from configured paths
        var modelFiles = assetLoader.GetModelFiles(assetPaths);

        if (modelName != null)
        {
            modelFiles = modelFiles.Where(f =>
                Path.GetFileNameWithoutExtension(f).Equals(modelName, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (modelFiles.Count == 0)
            {
                throw new FileNotFoundException($"Model '{modelName}' not found in configured model paths");
            }
        }

        Console.WriteLine($"Building {modelFiles.Count} model(s)");
        Console.WriteLine();

        // 5. Setup lineage service if needed
        lineageService = null;
        if (!noLineageTags)
        {
            lineageService = new LineageManifestService(serializer);
            lineageService.LoadManifest(projectPath);
        }

        // 6. Scan for connector configs from tables
        var connectorConfigs = ScanForConnectorConfigs(projectPath, registry, serializer);

        // 7. Build each model
        var composer = new ModelComposer(registry);

        // Register discovered connectors
        foreach (var connector in connectorConfigs)
        {
            composer.RegisterConnector(connector);
        }

        var models = new List<(Database, string, string)>();

        foreach (var modelFile in modelFiles)
        {
            var modelDef = serializer.LoadFromFile<ModelDefinition>(modelFile);
            var modelFileName = Path.GetFileNameWithoutExtension(modelFile);

            Console.WriteLine($"Building model: {modelDef.Name}");
            Console.WriteLine($"  Tables: {modelDef.Tables.Count}");
            Console.WriteLine($"  Relationships: {modelDef.Relationships.Count}");
            Console.WriteLine($"  Measures: {modelDef.Measures.Count}");
            Console.WriteLine();

            // Compose TOM database
            var database = composer.ComposeModel(modelDef, project.CompatibilityLevel, lineageService, project);

            // Validate TOM model
            var tomValidationResult = validator.ValidateTomModel(database, modelDef.Name);
            if (!tomValidationResult.IsValid)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(tomValidationResult.FormatMessages());
                Console.ResetColor();
                throw new InvalidOperationException($"TOM model validation failed for '{modelDef.Name}'");
            }

            if (tomValidationResult.HasWarnings)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(tomValidationResult.FormatMessages());
                Console.ResetColor();
                Console.WriteLine();
            }

            models.Add((database, modelFileName, modelDef.Name));
        }

        return models;
    }

    private static void GenerateTmdlOutput(Database database, string projectName, string targetPath, LineageManifestService? lineageService)
    {
        var sanitizedName = FileNameSanitizer.Sanitize(projectName);
        var modelOutputPath = Path.Combine(targetPath, sanitizedName);

        // Recreate output directory (clean build)
        if (Directory.Exists(modelOutputPath))
        {
            Console.WriteLine($"  Cleaning: {modelOutputPath}");
            Directory.Delete(modelOutputPath, true);
        }
        Directory.CreateDirectory(modelOutputPath);

        TmdlSerializer.SerializeDatabaseToFolder(database, modelOutputPath);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"  ✓ Generated: {modelOutputPath}");
        Console.ResetColor();

        if (lineageService != null)
        {
            Console.WriteLine($"  Lineage tags: {lineageService.NewTagCount} new, {lineageService.ExistingTagCount} existing");
        }

        Console.WriteLine();
    }

    private static void GeneratePbipOutput(Database database, string projectName, string targetPath, LineageManifestService? lineageService)
    {
        Console.WriteLine("Generating PBIP structure:");

        PbipGenerator.GeneratePbipStructure(database, projectName, targetPath);

        // Sanitize project name for display (same logic as in PbipGenerator)
        var sanitizedName = FileNameSanitizer.Sanitize(projectName);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"  ✓ Created: {Path.Combine(targetPath, $"{sanitizedName}.pbip")}");
        Console.WriteLine($"  ✓ Created: {Path.Combine(targetPath, $"{sanitizedName}.SemanticModel/")} (TMDL files)");
        Console.WriteLine($"  ✓ Created: {Path.Combine(targetPath, $"{sanitizedName}.Report/")} (PBIR files)");
        Console.ResetColor();

        if (lineageService != null)
        {
            Console.WriteLine($"  Lineage tags: {lineageService.NewTagCount} new, {lineageService.ExistingTagCount} existing");
        }

        Console.WriteLine();
    }

    private static void SaveLineageManifest(LineageManifestService? lineageService, string projectPath)
    {
        if (lineageService != null)
        {
            lineageService.SaveManifest(projectPath);

            if (lineageService.NewTagCount > 0)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"Lineage manifest updated with {lineageService.NewTagCount} new tag(s)");
                Console.ResetColor();
            }
        }
    }

    #endregion

    /// <summary>
    /// Scan for source type config files and extract connector configurations
    /// </summary>
    private static List<ConnectorConfig> ScanForConnectorConfigs(string projectPath, TableRegistry registry, YamlSerializer serializer)
    {
        var connectors = new List<ConnectorConfig>();
        var connectorNames = new HashSet<string>();

        // Check for source type config files (snowflake_config.yaml, sqlserver_config.yaml, etc.)
        var configFiles = Directory.GetFiles(projectPath, "*_config.yaml", SearchOption.AllDirectories)
            .Where(f => !f.Contains(".pbiscaffold") && !f.Contains("scaffold_config"));

        foreach (var configFile in configFiles)
        {
            try
            {
                var sourceConfig = serializer.LoadFromFile<SourceTypeConfig>(configFile);
                if (sourceConfig.Connector != null && !connectorNames.Contains(sourceConfig.Connector.Name))
                {
                    connectors.Add(sourceConfig.Connector);
                    connectorNames.Add(sourceConfig.Connector.Name);
                }
            }
            catch (Exception)
            {
                // Skip files that cannot be parsed as SourceTypeConfig —
                // the *_config.yaml glob may match unrelated config files.
            }
        }

        return connectors;
    }
}
