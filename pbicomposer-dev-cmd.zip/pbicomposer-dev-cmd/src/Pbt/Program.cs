using System.CommandLine;
using Pbt.Commands;

var rootCommand = new RootCommand(
    "pbt - Power BI Build Tool for semantic model composition");

// Add all commands
rootCommand.AddCommand(InitCommand.Create());
rootCommand.AddCommand(BuildCommand.Create());
rootCommand.AddCommand(ValidateCommand.Create());
rootCommand.AddCommand(ListCommand.Create());
rootCommand.AddCommand(ImportCommand.Create());
rootCommand.AddCommand(LineageCommand.Create());
rootCommand.AddCommand(RunOperationCommand.Create());

return await rootCommand.InvokeAsync(args);
