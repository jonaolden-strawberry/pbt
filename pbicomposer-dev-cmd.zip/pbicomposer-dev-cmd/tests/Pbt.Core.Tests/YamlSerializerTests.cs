using Pbt.Core.Infrastructure;
using Pbt.Core.Models;

namespace Pbt.Core.Tests;

public class YamlSerializerTests
{
    private readonly YamlSerializer _serializer = new();

    [Fact]
    public void LoadProjectDefinition_ShouldDeserialize()
    {
        // Arrange
        var yaml = @"
name: SampleProject
description: Example Power BI Composer project
compatibility_level: 1600
";

        // Act
        var project = _serializer.Deserialize<ProjectDefinition>(yaml);

        // Assert
        Assert.Equal("SampleProject", project.Name);
        Assert.Equal("Example Power BI Composer project", project.Description);
        Assert.Equal(1600, project.CompatibilityLevel);
    }

    [Fact]
    public void LoadTableDefinition_ShouldDeserialize()
    {
        // Arrange
        var yaml = @"
name: Sales
description: Sales fact table
m_expression: |
  let
    Source = #table(...)
  in
    Source

columns:
  - name: OrderID
    type: Int64
    source_column: OrderID
    description: Unique order identifier

  - name: Amount
    type: Decimal
    format_string: ""$#,##0.00""
";

        // Act
        var table = _serializer.Deserialize<TableDefinition>(yaml);

        // Assert
        Assert.Equal("Sales", table.Name);
        Assert.Equal("Sales fact table", table.Description);
        Assert.Contains("let", table.MExpression);
        Assert.Equal(2, table.Columns.Count);
        Assert.Equal("OrderID", table.Columns[0].Name);
        Assert.Equal("Int64", table.Columns[0].Type);
        Assert.Equal("OrderID", table.Columns[0].SourceColumn);
        Assert.Equal("Amount", table.Columns[1].Name);
        Assert.Equal("$#,##0.00", table.Columns[1].FormatString);
    }

    [Fact]
    public void LoadModelDefinition_ShouldDeserialize()
    {
        // Arrange
        var yaml = @"
name: SalesAnalytics
description: Sales analytics model

tables:
  - ref: Sales
  - ref: Customers

relationships:
  - from_table: Sales
    from_column: CustomerID
    to_table: Customers
    to_column: CustomerID
    cardinality: ManyToOne
    cross_filter_direction: Both
    active: true

measures:
  - name: Total Sales
    table: Sales
    expression: SUM(Sales[Amount])
    format_string: ""$#,##0.00""
    display_folder: Sales Metrics
";

        // Act
        var model = _serializer.Deserialize<ModelDefinition>(yaml);

        // Assert
        Assert.Equal("SalesAnalytics", model.Name);
        Assert.Equal("Sales analytics model", model.Description);
        Assert.Equal(2, model.Tables.Count);
        Assert.Equal("Sales", model.Tables[0].Ref);
        Assert.Equal("Customers", model.Tables[1].Ref);

        Assert.Single(model.Relationships);
        Assert.Equal("Sales", model.Relationships[0].FromTable);
        Assert.Equal("CustomerID", model.Relationships[0].FromColumn);
        Assert.Equal("Customers", model.Relationships[0].ToTable);
        Assert.Equal("ManyToOne", model.Relationships[0].Cardinality);
        Assert.Equal("Both", model.Relationships[0].CrossFilterDirection);
        Assert.True(model.Relationships[0].Active);

        Assert.Single(model.Measures);
        Assert.Equal("Total Sales", model.Measures[0].Name);
        Assert.Equal("Sales", model.Measures[0].Table);
        Assert.Equal("SUM(Sales[Amount])", model.Measures[0].Expression);
        Assert.Equal("Sales Metrics", model.Measures[0].DisplayFolder);
    }

    [Fact]
    public void SerializeAndDeserialize_ShouldRoundTrip()
    {
        // Arrange
        var original = new TableDefinition
        {
            Name = "TestTable",
            Description = "Test description",
            MExpression = "let Source = ... in Source",
            Columns = new List<ColumnDefinition>
            {
                new() { Name = "ID", Type = "Int64", SourceColumn = "id" },
                new() { Name = "Name", Type = "String", FormatString = null }
            }
        };

        // Act
        var yaml = _serializer.Serialize(original);
        var deserialized = _serializer.Deserialize<TableDefinition>(yaml);

        // Assert
        Assert.Equal(original.Name, deserialized.Name);
        Assert.Equal(original.Description, deserialized.Description);
        Assert.Equal(original.MExpression, deserialized.MExpression);
        Assert.Equal(original.Columns.Count, deserialized.Columns.Count);
        Assert.Equal(original.Columns[0].Name, deserialized.Columns[0].Name);
        Assert.Equal(original.Columns[0].SourceColumn, deserialized.Columns[0].SourceColumn);
    }

    [Fact]
    public void LoadTableDefinition_WithCalculatedColumn_ShouldDeserialize()
    {
        // Arrange
        var yaml = @"
name: Date
description: Date dimension table
columns:
  - name: Date
    type: DateTime
    source_column: DATE_FMT
    description: Calendar date

  - name: Last and Next 12 Months
    type: Boolean
    expression: 'IF( [Month Fmt] >= DATEADD( MONTH, -12, TODAY() ) && [Month Fmt] <= DATEADD( MONTH, 12, TODAY() ), TRUE(), FALSE() )'
    description: Flag for dates within 12 months range
    format_string: '""TRUE"";""TRUE"";""FALSE""'
    is_hidden: true
    display_folder: Sets
";

        // Act
        var table = _serializer.Deserialize<TableDefinition>(yaml);

        // Assert
        Assert.Equal("Date", table.Name);
        Assert.Equal(2, table.Columns.Count);

        // Verify data column
        var dateColumn = table.Columns[0];
        Assert.Equal("Date", dateColumn.Name);
        Assert.Equal("DateTime", dateColumn.Type);
        Assert.Equal("DATE_FMT", dateColumn.SourceColumn);
        Assert.Null(dateColumn.Expression);

        // Verify calculated column
        var calcColumn = table.Columns[1];
        Assert.Equal("Last and Next 12 Months", calcColumn.Name);
        Assert.Equal("Boolean", calcColumn.Type);
        Assert.Null(calcColumn.SourceColumn);
        Assert.NotNull(calcColumn.Expression);
        Assert.Contains("DATEADD", calcColumn.Expression);
        Assert.Equal(true, calcColumn.IsHidden);
        Assert.Equal("Sets", calcColumn.DisplayFolder);
        Assert.Equal("\"TRUE\";\"TRUE\";\"FALSE\"", calcColumn.FormatString);
    }

    [Fact]
    public void SerializeAndDeserialize_WithCalculatedColumn_ShouldRoundTrip()
    {
        // Arrange
        var original = new TableDefinition
        {
            Name = "TestTable",
            Description = "Test description",
            MExpression = "let Source = ... in Source",
            Columns = new List<ColumnDefinition>
            {
                new() { Name = "ID", Type = "Int64", SourceColumn = "id" },
                new()
                {
                    Name = "Calculated Column",
                    Type = "Decimal",
                    Expression = "DIVIDE([Amount], [Quantity], 0)",
                    Description = "Unit price calculation",
                    FormatString = "$#,##0.00",
                    IsHidden = true,
                    DisplayFolder = "Calculations"
                }
            }
        };

        // Act
        var yaml = _serializer.Serialize(original);
        var deserialized = _serializer.Deserialize<TableDefinition>(yaml);

        // Assert
        Assert.Equal(original.Name, deserialized.Name);
        Assert.Equal(original.Columns.Count, deserialized.Columns.Count);

        // Verify data column round-trip
        Assert.Equal(original.Columns[0].Name, deserialized.Columns[0].Name);
        Assert.Equal(original.Columns[0].SourceColumn, deserialized.Columns[0].SourceColumn);
        Assert.Null(deserialized.Columns[0].Expression);

        // Verify calculated column round-trip
        var calcColumn = deserialized.Columns[1];
        Assert.Equal("Calculated Column", calcColumn.Name);
        Assert.Equal("Decimal", calcColumn.Type);
        Assert.Null(calcColumn.SourceColumn);
        Assert.Equal("DIVIDE([Amount], [Quantity], 0)", calcColumn.Expression);
        Assert.Equal("Unit price calculation", calcColumn.Description);
        Assert.Equal("$#,##0.00", calcColumn.FormatString);
        Assert.True(calcColumn.IsHidden);
        Assert.Equal("Calculations", calcColumn.DisplayFolder);
    }

    [Fact]
    public void LoadFromFile_ExampleProject_ShouldDeserialize()
    {
        // Arrange
        var projectRoot = FindProjectRoot();
        var salesTablePath = Path.Combine(projectRoot, "examples/sample_project/tables/sales.yaml");

        // Skip if running in environment without example files
        if (!File.Exists(salesTablePath))
        {
            return;
        }

        // Act
        var table = _serializer.LoadFromFile<TableDefinition>(salesTablePath);

        // Assert
        Assert.Equal("Sales", table.Name);
        Assert.NotEmpty(table.Columns);
        Assert.Contains(table.Columns, c => c.Name == "OrderID");
    }

    private string FindProjectRoot()
    {
        var directory = Directory.GetCurrentDirectory();
        while (directory != null && !File.Exists(Path.Combine(directory, "pbicomposer.sln")))
        {
            directory = Directory.GetParent(directory)?.FullName;
        }
        return directory ?? Directory.GetCurrentDirectory();
    }
}
